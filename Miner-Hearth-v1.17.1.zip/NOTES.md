# Miner Hearth v1.17.1

- Firelit stone-wall dashboard background (shows straight away).
- Settings > Appearance > "Dashboard background" (on by default) to turn it off.
- A footer with the running version ("Miner Hearth v1.17.1").

The setting and the footer are program changes: press **Quick restart** after applying.
**Roll back** returns to v1.17.0 (the footer disappears).
